using System;

namespace eCommerce.Models.Dtos;

public class LoginResult
{
  public string AccessToken {get;set;}
}
