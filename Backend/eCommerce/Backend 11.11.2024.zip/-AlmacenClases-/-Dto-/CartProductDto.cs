//using System;

//namespace eCommerce.Models.Dtos;

//public class CartProductDto
//{
//  public long CartId { get; set; }
//  public long ProductId { get; set; }
//  public required int Quantity {  get; set; } 
//}
