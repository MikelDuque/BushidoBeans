﻿//using eCommerce.Models.Database.Entities;

//namespace eCommerce.Models.Database.Repositories;

//public class ReviewRepository : Repository<Review>
//{
//    public ReviewRepository(DataContext dbContext) : base(dbContext)
//    {
//    }
//}
