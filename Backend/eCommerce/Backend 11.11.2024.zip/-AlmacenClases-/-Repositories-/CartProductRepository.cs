//using System;
//using eCommerce.Models.Database.Entities;

//namespace eCommerce.Models.Database.Repositories;

//public class CartProductRepository : Repository<CartProduct>
//{
//  public CartProductRepository(DataContext dbContext) : base(dbContext)
//    {
//    }
//}
