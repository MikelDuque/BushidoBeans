﻿//using eCommerce.Models.Database.Entities;

//namespace eCommerce.Models.Database.Repositories;

//public class CartRepository : Repository<Cart>
//{
//    public CartRepository(DataContext dbContext) : base(dbContext)
//    {
//    }
//}
