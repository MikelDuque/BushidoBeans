﻿namespace eCommerce
{
    public class Settings
    {
        public const string SECTION_NAME = "Settings";
        public string JwtKey { get; init; } = null!;
    }
}
