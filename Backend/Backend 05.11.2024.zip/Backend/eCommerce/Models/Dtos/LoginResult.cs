using System;

namespace eCommerce.Models.Dtos;

public class LoginResult
{
  public required string AccessToken {get;set;}
}
