-----OBSERVACIONES ROCÍO-----

Refactorizaciones:

1. Arquitectura de ficheros como formLogim
2. flex corregirlo en el navlink
3. el main ha de ser un grid
4. 2 import en el fichero de globales index.css y luego en cada componente se especifica cual tipografia y ya
5. footer: position relative con los bottom/left .. lo vamos a pasar a un layout grid / flex, por el tema del responsive
6. el header: hay que usar un layout