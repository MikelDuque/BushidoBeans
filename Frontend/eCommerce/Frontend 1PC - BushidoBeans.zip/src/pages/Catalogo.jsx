import Header from "../components/Header";
import Footer from "../components/Footer";

function Catalogo() {
  return (
    <>
      <head>
        <title>Bushido Beans</title>
      </head>

      <body>
        <Header />
        <main>
          <div>Probando
          </div>
        </main>
        <Footer />
      </body>
    </>
  );
}

export default Catalogo;